const path = require('path');
const multer = require('multer');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        console.log('called destination');

        cb(null, './server/uploads');
    },
    filename: (req, file, cb) => {
        console.log('called filename');

        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
        console.log('Nova imagem salva!')
    }
});

module.exports = multer({ storage: storage });