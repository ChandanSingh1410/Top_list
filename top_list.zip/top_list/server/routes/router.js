const express = require('express');
const fs = require('fs');
const path = require('path');
const route = express.Router()

const services = require('../services/render');
const controller = require('../controller/controller');
var Userdb = require('../model/model');
const multerConf = require('../config/multer');

/**
 *  @description Root Route
 *  @method GET /
 */
route.get('/', services.homeRoutes);

/**
 *  @description add users
 *  @method GET /add-user
 */
route.get('/add-user', services.add_user)

/**
 *  @description for update user
 *  @method GET /update-user
 */
route.get('/update-user', services.update_user)


// API
route.post('/api/users', multerConf.single('image'), (req, res) => {
    if(!req.body){
        res.status(400).send({ message : "Content can not be emtpy!"});
        return;
    }
    // console.log("sanjay");
    // var x = path.join(__dirname, 'uploads');
    // if(x == null)console.log("sanjay----------------------------");
    console.log(req.body);
    // new user
    const user = new Userdb({
        name : req.body.name,
        email : req.body.email,
        gender: req.body.gender,
        img: {
            data: fs.readFileSync(path.join(__dirname,"../uploads/", req.file.filename)),
            contentType: 'image/png'
        },
        status : req.body.status
    })
    user
    .save(user)
    .then(data => {
        //res.send(data)
        res.redirect('/add-user');
    })
    .catch(err =>{
        res.status(500).send({
            message : err.message || "Some error occurred while creating a create operation"
        });
    });

});
route.get('/api/users', controller.find);
route.put('/api/users/:id', controller.update);
route.delete('/api/users/:id', controller.delete);


module.exports = route