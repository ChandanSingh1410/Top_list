import { VscStarEmpty } from "react-icons/vsc";
const Star=()=>{
    return(
        <>
            <VscStarEmpty/>
            <VscStarEmpty/>
            <VscStarEmpty/> 
            <VscStarEmpty/>
            <VscStarEmpty/>
        </>
    );
};
export default Star;