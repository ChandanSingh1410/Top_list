const Atable=[{
    Artist:"Arijit Singh",
    Date_of_Birth:"25 April 1987",
    Songs:"Dhundlo Tum, Thodi Si Jagah, Binte dil"
},
{
    Artist:"Shreya Ghoshal",
    Date_of_Birth:"12 March 1984",
    Songs:"Kshan Mohare, Man He, Hans Mat Pagli"
},
{
    Artist:"Lata Mangeshkar",
    Date_of_Birth:"28 September 1929",
    Songs:"Ye Samaa Samaa Hai Pyar Ka, Dekha Ek Khwaab"
},
{
    Artist:"Kumar Sanu",
    Date_of_Birth:"30 July 1973",
    Songs:"Mouka Milenga To Hum, Do Dil Mil Rahe Hain"
}
,
{
    Artist:"Sonu Nigam",
    Date_of_Birth:"30 July 1973",
    Songs:"Main Agar Kahoon, Suraj Hua Maddham, Kal Ho Naa Ho"
},
{
    Artist:"Asha Bhosle",
    Date_of_Birth:" 8 September 1933",
    Songs:"Raat Baaki Baat Baki, Dum Maaro Dum, Hare Rama Hare Krishna"
},
{
    Artist:"Udit Narayan",
    Date_of_Birth:" 1 December 1955",
    Songs:"Mubarak ho Tumko ye Shadi Tumhari, Phool Mangoo Naa Bahaar"
},
{
    Artist:"A. R. Rahman",
    Date_of_Birth:"6 January 1967",
    Songs:"Dil Se Re, Tum Ho, Enna Sona, Matargashti, Humma Humma"
},
{
    Artist:"Kishore Kumar",
    Date_of_Birth:"4 August 1929",
    Songs:"Aap Ki Ankhon Mein Kuch, Bheegi Bheegi Raaton Mein"
},
{
    Artist:"Shankar Mahadevan",
    Date_of_Birth:"3 March 1967",
    Songs:"Tere Naina,  Koi Kahe Kehta Rahe, Uff Teri Adaa"
}

]
export default Atable;